
function clinic (lastname, firstname){
    const fullname = [firstname + " "+lastname]
   // fullname.join(' ')
    console.log(`Hello, ${fullname}! How can we help you today?`)
}

clinic("Quejada", "Kurt Ivan");