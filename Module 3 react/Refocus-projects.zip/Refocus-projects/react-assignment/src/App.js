import "./App.css";

function App() {
  return (
    <header>
      <div className="name">Kurt Quejada</div>
      <div>
        <button>Home</button>
        <button>About</button>
      </div>
    </header>
  );
}

export default App;
