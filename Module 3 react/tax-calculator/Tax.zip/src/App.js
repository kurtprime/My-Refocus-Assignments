import React, { Component } from "react";
import TaxCalculator from "./components/TaxCalculator";

export default class App extends Component {
  render() {
    return <TaxCalculator />;
  }
}
